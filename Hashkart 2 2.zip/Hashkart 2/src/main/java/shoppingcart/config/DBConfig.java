package shoppingcart.config;

import org.hibernate.SessionFactory;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBuilder;
import shoppingcart.model.Category;
import shoppingcart.model.Product;

import javax.sql.DataSource;
import java.util.Properties;

@EnableAutoConfiguration
@ComponentScan("shoppingcart")
public class DBConfig {

    @Bean(name="dataSource")
    public DataSource getH2DataSource()
    {
        DriverManagerDataSource dataSource=new DriverManagerDataSource();
        dataSource.setDriverClassName("org.h2.Driver");
        dataSource.setUrl("");
        dataSource.setUsername("");
        dataSource.setPassword("");
        System.out.println("------DataSource object got created-----");
        return dataSource;
    }

    @Bean(name="sessionFactory")
    public SessionFactory getSessionFactory(){

        Properties hibernateprop= new Properties();
        hibernateprop.put("hibernate.hdm2ddl.auto","update");
        hibernateprop.put("hibernate.dialect","org.hibernate.dialect.H2Dialect");

        LocalSessionFactoryBuilder localFactory=new LocalSessionFactoryBuilder(getH2DataSource());

        localFactory.addAnnotatedClass(Category.class);
        localFactory.addAnnotatedClass(Product.class);

        localFactory.addProperties(hibernateprop);

        System.out.println("--------SessionFactory object is created------");

        return localFactory.buildSessionFactory();

    }

    @Bean(name="TxManager")
    public HibernateTransactionManager getTransactionManager(SessionFactory sessionFactory){
        System.out.println("--------Transaction manager object created--------");
        return new HibernateTransactionManager(sessionFactory);
    }
}
