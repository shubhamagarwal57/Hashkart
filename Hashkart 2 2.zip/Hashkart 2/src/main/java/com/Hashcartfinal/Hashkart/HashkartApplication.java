package com.Hashcartfinal.Hashkart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HashkartApplication {

	public static void main(String[] args) {
		SpringApplication.run(HashkartApplication.class, args);
	}

}
