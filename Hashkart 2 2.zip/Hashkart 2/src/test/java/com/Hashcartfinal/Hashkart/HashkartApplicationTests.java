package com.Hashcartfinal.Hashkart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HashkartApplicationTests {

	@Test
	void contextLoads() {
	}

}
