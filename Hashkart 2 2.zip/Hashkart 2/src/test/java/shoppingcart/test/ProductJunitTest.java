package shoppingcart.test;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.test.context.event.annotation.BeforeTestClass;
import shoppingcart.DAO.CategoryDAO;
import shoppingcart.DAO.ProductDAO;
import shoppingcart.model.Product;

import static org.springframework.test.util.AssertionErrors.assertTrue;

public class ProductJunitTest {

    @Autowired
    static ProductDAO productDAO;

    @BeforeTestClass
    public static void executeFirst()
    {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
        context.scan("shoppingcart");
        context.refresh();

        productDAO= (ProductDAO) context.getBean("productDAO");

    }

    @Test
    public void addProductTest()
    {

        Product product=new Product();
        product.setProductName("T-shirt");
        product.setProductName("UCD");
        product.setPrice(8000);
        product.setStock(45);
        product.setCategoryId(18);
        product.setSupplierId(15);

        assertTrue("problem in adding product",productDAO.addProduct(product));
    }
}
