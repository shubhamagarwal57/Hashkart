package shoppingcart.test;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.test.context.event.annotation.BeforeTestClass;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import shoppingcart.DAO.CategoryDAO;
import shoppingcart.model.Category;

import static org.springframework.test.util.AssertionErrors.assertTrue;


public class CategoryJunitTest {
     @Autowired
    static CategoryDAO categoryDAO;

    @BeforeTestClass
    public static void executeFirst()
    {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
        context.scan("ECommerce");
        context.refresh();

        categoryDAO = (CategoryDAO) context.getBean("categoryDAO");

    }

    @Test
    public void addCategoryTest(){
        Category category=new Category();

        category.setCategoryName("T-shirt");
        category.setCategoryDesc("All variety of T-shirt");

        assertTrue("problem in adding category",categoryDAO.addCategory(category));
    }

}
